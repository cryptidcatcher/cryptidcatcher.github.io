import java.util.ArrayList;

public class AppointmentService {

	//list of appointments
	private ArrayList<Appointment> appointmentList = new ArrayList<Appointment>();
	
	//getter
	public ArrayList<Appointment> getAppointments(){
		return appointmentList;
	}
	
	//add contact to appointment list
	public void addAppointment(Appointment appointmentId) {
		 for (Appointment appointment: appointmentList) {
			 if (appointmentList.contains(appointment)) {
				 return;				 
			 	}
			 appointmentList.add(appointmentId);
			 }
	
	}
	
	//delete contact from list
	public void deleteAppointment(String appointmentId) {
		for (Appointment appointment: appointmentList) {
			 if (appointmentList.contains(appointment)) {
				 appointmentList.remove(appointment);			 
			 	}
			 return;
			 }
	}
}
