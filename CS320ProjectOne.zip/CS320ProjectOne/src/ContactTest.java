
public class ContactTest {
//FIXME later
}
