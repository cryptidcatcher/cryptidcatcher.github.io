 
public class Contact {
	//strings
	private final String contactId;
	private String firstName;
	private String lastName;
	private String phone;
	private String address;
	
	//enforce length requirements
	public Contact (String contactId, String firstName, String lastName, String phone, String address) {
	if(contactId == null || firstName == null || lastName == null || phone == null || address == null
			|| contactId.length() > 10 || firstName.length() > 10 || lastName.length() > 10 || 
			phone.length() > 10 || phone.length() < 10 || address.length() > 30) {
		throw new IllegalArgumentException("Error! Invalid Argument.");			
		}
	
	//getters
	this.contactId = contactId;
	this.firstName = firstName;
	this.lastName = lastName;
	this.phone = phone;
	this.address = address;
	}
	
	//setters
	public void setFirstName(String firstName) {
		this.firstName = firstName;
		if (firstName == null || firstName.length() > 10) {
			throw new IllegalArgumentException("Error! Invalid Argument.");
		}
	}
	
	public void setLastName(String lastName) {
		this.lastName = lastName;
		if (lastName == null || lastName.length() > 10) {
			throw new IllegalArgumentException("Error! Invalid Argument.");
		}
	}

	public void setPhone(String phone) {
		this.phone = phone;
		if (phone == null || phone.length() > 10 || phone.length() < 10) {
			throw new IllegalArgumentException("Error! Invalid Argument.");
		}
	}

	public void setAddress(String address) {
		this.address = address;
		if (address == null || address.length() > 10) {
			throw new IllegalArgumentException("Error! Invalid Argument.");
		}
	}
}
