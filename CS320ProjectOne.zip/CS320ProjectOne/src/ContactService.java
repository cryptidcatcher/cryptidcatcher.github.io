import java.util.ArrayList;

package services;

public class ContactService {
	//list of contacts
	private ArrayList<Contact> contactList = new ArrayList<Contact>();
	
	//getter
	public ArrayList<Contact> getContacts(){
		return contactList;
	}
	
	//add contact to contact list
	public void addContact(Contact contactId) {
		 for (Contact contact: contactList) {
			 if (contactList.contains(contact)) {
				 return;				 
			 	}
			 contactList.add(contactId);
			 }
	
	}
	
	//delete contact from list
	public void deleteContact(String contactId) {
		for (Contact contact: contactList) {
			 if (contactList.contains(contact)) {
				contactList.remove(contact);			 
			 	}
			 return;
			 }
	}
	
	//update contact first name in list
	public void updateFirstName (String contactId, String firstName) {
		for (Contact contact: contactList) {
			 if (contactList.contains(contact)) {
				contact.setFirstName(firstName);
			 	}
			 return;
			 }
	}
	
	//update contact first name in list
	public void updateLastName (String contactId, String lastName) {
			for (Contact contact: contactList) {
				 if (contactList.contains(contact)) {
					 contact.setLastName(lastName);
				 	}
				 return;
				 }
	}
	
	//update contact phone number in list
	public void updatePhone (String contactId, String phone) {
				for (Contact contact: contactList) {
					 if (contactList.contains(contact)) {
						 contact.setPhone(phone);
					 	}
					 return;
					 }
				
	}
	
	//update contact address in list
	public void updateAddress (String contactId, String address) {
					for (Contact contact: contactList) {
						 if (contactList.contains(contact)) {
							 contact.setAddress(address);
						 	}
						 return;
						 }
	}
}
