package services;

import static org.junit.Assert.assertEquals;
import org.junit.*;
import static org.junit.jupiter.api.Assertions.*;

import static org.junit.jupiter.api.assertions;
import static org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Test;

import service.ContactService;

public class ContactServiceTest {
 	@Test
 	
 	getContacts();
 	
	/*none of this is working ahhHhhhHhh
 	I've reread the articles linked in last week's resources
 	many times, but I can't seem to make it work.
 	I manually reviewed all my code and used the built in
 	debugger, but the JUNIT testing specifically won't run.
 	I'm sorry :-(
 	*/
}
