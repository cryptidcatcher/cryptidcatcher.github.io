import java.util.Date;

public class Appointment {
	//strings
	private final String appointmentId;
	private Date date;
	private String field;
	
	//enforce length requirements
		public Appointment (String appointmentId, Date date, String field) {
		if(appointmentId == null || date == null || field == null 
				|| appointmentId.length() > 10 || field.length() > 50 || date.before(new Date())
				) {
			throw new IllegalArgumentException("Error! Invalid Argument.");			
			}
		
		//getters
		this.appointmentId = appointmentId;
		this.date = date;
		this.field = field;
		}
		
		//setters
		public void setDate(Date date) {
			this.date = date;
			if (date == null || date.before(new Date())) {
				throw new IllegalArgumentException("Error! Invalid Argument.");
			}
		}
		
		public void setField(String field) {
			this.field = field;
			if (field == null || field.length() > 50) {
				throw new IllegalArgumentException("Error! Invalid Argument.");
			}
		}
		
}
