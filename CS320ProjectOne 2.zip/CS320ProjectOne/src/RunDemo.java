import java.util.Calendar;
import java.util.Date;
import java.util.List;

public class RunDemo {
    public static void main(String[] args) {
        try {
            ContactService contactService = new ContactService();
            Contact contact = new Contact("C1", "Alice", "Smith", "1234567890", "123 Main St");
            contactService.addContact(contact);
            List<Contact> contacts = contactService.getContactsSortedByLastName();
            System.out.println("Contacts: " + contacts.size());

            TaskService taskService = new TaskService();
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_MONTH, 1);
            Task task = new Task("T1", "Task one", "Do homework", cal.getTime(), Task.Priority.HIGH);
            taskService.addTask(task);
            Task nextTask = taskService.getNextDueTask();
            System.out.println("Next due task: " + nextTask.getTaskId());

            AppointmentService appointmentService = new AppointmentService();
            cal.add(Calendar.DAY_OF_MONTH, 1);
            Appointment appointment = new Appointment("A1", cal.getTime(), "Dentist");
            appointmentService.addAppointment(appointment);
            List<Appointment> appointments = appointmentService.getAppointmentsSortedByDate();
            System.out.println("Appointments: " + appointments.size());

            System.out.println("RunDemo completed successfully.");
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }
}
