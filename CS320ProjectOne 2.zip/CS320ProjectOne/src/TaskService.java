
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;

public class TaskService {
    private final Map<String, Task> taskMap = new HashMap<>();
    private final List<Task> taskList = new ArrayList<>();

    public List<Task> getTasks() {
        return new ArrayList<>(taskList);
    }

    public Task getTaskById(String taskId) {
        if (taskId == null) {
            throw new IllegalArgumentException("Task id cannot be null.");
        }
        return taskMap.get(taskId);
    }

    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("Task cannot be null.");
        }
        String taskId = task.getTaskId();
        if (taskMap.containsKey(taskId)) {
            throw new IllegalArgumentException("Task id already exists.");
        }
        taskMap.put(taskId, task);
        taskList.add(task);
    }

    public void deleteTask(String taskId) {
        Task task = getTaskById(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task not found.");
        }
        taskMap.remove(taskId);
        taskList.remove(task);
    }

    public void updateTaskName(String taskId, String name) {
        Task task = getTaskById(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task not found.");
        }
        task.setName(name);
    }

    public void updateTaskDescription(String taskId, String description) {
        Task task = getTaskById(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task not found.");
        }
        task.setDescription(description);
    }

    public void updateTaskDueDate(String taskId, Date dueDate) {
        Task task = getTaskById(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task not found.");
        }
        task.setDueDate(dueDate);
    }

    public void updateTaskPriority(String taskId, Task.Priority priority) {
        Task task = getTaskById(taskId);
        if (task == null) {
            throw new IllegalArgumentException("Task not found.");
        }
        task.setPriority(priority);
    }

    public List<Task> getTasksSortedByDueDate() {
        List<Task> sorted = new ArrayList<>(taskList);
        sorted.sort(Comparator.comparing(Task::getDueDate));
        return sorted;
    }

    public List<Task> getTasksSortedByPriority() {
        List<Task> sorted = new ArrayList<>(taskList);
        sorted.sort(Comparator.comparing(Task::getPriority)
                .thenComparing(Task::getDueDate));
        return sorted;
    }

    public List<Task> getOverdueTasks(Date currentDate) {
        if (currentDate == null) {
            throw new IllegalArgumentException("Current date cannot be null.");
        }
        List<Task> overdue = new ArrayList<>();
        for (Task task : taskList) {
            if (task.getDueDate().before(currentDate)) {
                overdue.add(task);
            }
        }
        return overdue;
    }

    public Task getNextDueTask() {
        if (taskList.isEmpty()) {
            return null;
        }
        PriorityQueue<Task> dueQueue = new PriorityQueue<>(Comparator.comparing(Task::getDueDate));
        dueQueue.addAll(taskList);
        return dueQueue.peek();
    }

    public List<Task> searchTasks(String keyword) {
        if (keyword == null) {
            throw new IllegalArgumentException("Search keyword cannot be null.");
        }
        String normalized = keyword.toLowerCase();
        List<Task> results = new ArrayList<>();
        for (Task task : taskList) {
            if (task.getName().toLowerCase().contains(normalized)
                    || task.getDescription().toLowerCase().contains(normalized)) {
                results.add(task);
            }
        }
        return results;
    }
}
