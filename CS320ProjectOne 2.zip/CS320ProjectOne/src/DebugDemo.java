import java.util.Calendar;
import java.util.List;

public class DebugDemo {
    public static void main(String[] args) throws Exception {
        ContactService contactService = new ContactService();
        Contact contact = new Contact("C1", "Alice", "Smith", "1234567890", "123 Main St");
        contactService.addContact(contact);
        TaskService taskService = new TaskService();
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        Task task = new Task("T1", "Task one", "Do homework", cal.getTime(), Task.Priority.HIGH);
        taskService.addTask(task);
        AppointmentService appointmentService = new AppointmentService();
        cal.add(Calendar.DAY_OF_MONTH, 1);
        Appointment appointment = new Appointment("A1", cal.getTime(), "Dentist");
        appointmentService.addAppointment(appointment);

        System.out.println("DebugDemo ready. Press Enter to continue...");
        System.in.read();
        System.out.println("Continuing after debugger attach.");

        List<Contact> contacts = contactService.getContactsSortedByLastName();
        List<Task> tasks = taskService.getTasksSortedByDueDate();
        List<Appointment> appointments = appointmentService.getAppointmentsSortedByDate();

        System.out.println("Contacts: " + contacts.size());
        System.out.println("Tasks: " + tasks.size());
        System.out.println("Appointments: " + appointments.size());
    }
}
