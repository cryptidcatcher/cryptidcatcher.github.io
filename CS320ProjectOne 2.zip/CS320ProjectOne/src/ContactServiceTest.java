public class ContactServiceTest {
}
