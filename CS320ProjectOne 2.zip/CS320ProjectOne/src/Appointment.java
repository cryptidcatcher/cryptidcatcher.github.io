import java.util.Date;
import java.util.Objects;

public class Appointment {
    private final String appointmentId;
    private Date date;
    private String field;

    public Appointment(String appointmentId, Date date, String field) {
        if (appointmentId == null || date == null || field == null
                || appointmentId.length() > 10 || field.length() > 50 || date.before(new Date())) {
            throw new IllegalArgumentException("Error! Invalid Argument.");
        }

        this.appointmentId = appointmentId;
        this.date = new Date(date.getTime());
        this.field = field;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getDate() {
        return new Date(date.getTime());
    }

    public String getField() {
        return field;
    }

    public void setDate(Date date) {
        if (date == null || date.before(new Date())) {
            throw new IllegalArgumentException("Error! Invalid Argument.");
        }
        this.date = new Date(date.getTime());
    }

    public void setField(String field) {
        if (field == null || field.length() > 50) {
            throw new IllegalArgumentException("Error! Invalid Argument.");
        }
        this.field = field;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Appointment)) {
            return false;
        }
        Appointment other = (Appointment) obj;
        return Objects.equals(appointmentId, other.appointmentId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(appointmentId);
    }
}
