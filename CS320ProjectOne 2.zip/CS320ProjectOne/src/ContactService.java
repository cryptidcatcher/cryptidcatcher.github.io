import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ContactService {
    private final Map<String, Contact> contactMap = new HashMap<>();
    private final List<Contact> contactList = new ArrayList<>();
    private final Set<String> phoneSet = new HashSet<>();

    public List<Contact> getContacts() {
        return new ArrayList<>(contactList);
    }

    public Contact getContactById(String contactId) {
        if (contactId == null) {
            throw new IllegalArgumentException("Contact id cannot be null.");
        }
        return contactMap.get(contactId);
    }

    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("Contact cannot be null.");
        }
        String contactId = contact.getContactId();
        if (contactMap.containsKey(contactId)) {
            throw new IllegalArgumentException("Contact id already exists.");
        }
        if (!phoneSet.add(contact.getPhone())) {
            throw new IllegalArgumentException("Phone number already in use.");
        }
        contactMap.put(contactId, contact);
        contactList.add(contact);
    }

    public void deleteContact(String contactId) {
        Contact contact = getContactById(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found.");
        }
        contactMap.remove(contactId);
        contactList.remove(contact);
        phoneSet.remove(contact.getPhone());
    }

    public void updateFirstName(String contactId, String firstName) {
        Contact contact = getContactById(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found.");
        }
        contact.setFirstName(firstName);
    }

    public void updateLastName(String contactId, String lastName) {
        Contact contact = getContactById(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found.");
        }
        contact.setLastName(lastName);
    }

    public void updatePhone(String contactId, String phone) {
        Contact contact = getContactById(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found.");
        }
        if (!contact.getPhone().equals(phone) && !phoneSet.add(phone)) {
            throw new IllegalArgumentException("Phone number already in use.");
        }
        phoneSet.remove(contact.getPhone());
        contact.setPhone(phone);
        phoneSet.add(phone);
    }

    public void updateAddress(String contactId, String address) {
        Contact contact = getContactById(contactId);
        if (contact == null) {
            throw new IllegalArgumentException("Contact not found.");
        }
        contact.setAddress(address);
    }

    public List<Contact> getContactsSortedByLastName() {
        List<Contact> sorted = new ArrayList<>(contactList);
        sorted.sort(Comparator.comparing(Contact::getLastName)
                .thenComparing(Contact::getFirstName));
        return sorted;
    }

    public List<Contact> searchContactsByNamePrefix(String prefix) {
        if (prefix == null) {
            throw new IllegalArgumentException("Search prefix cannot be null.");
        }
        String normalized = prefix.toLowerCase();
        List<Contact> results = new ArrayList<>();
        for (Contact contact : contactList) {
            if (contact.getFirstName().toLowerCase().startsWith(normalized)
                    || contact.getLastName().toLowerCase().startsWith(normalized)) {
                results.add(contact);
            }
        }
        return results;
    }
}