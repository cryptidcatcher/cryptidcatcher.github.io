
import java.util.Date;
import java.util.Objects;

public class Task {
    public enum Priority {
        HIGH,
        MEDIUM,
        LOW
    }

    private final String taskId;
    private String name;
    private String description;
    private Date dueDate;
    private Priority priority;

    public Task(String taskId, String name, String description, Date dueDate, Priority priority) {
        if (taskId == null || name == null || description == null || dueDate == null || priority == null
                || taskId.length() > 10 || name.length() > 20 || description.length() > 50
                || dueDate.before(new Date())) {
            throw new IllegalArgumentException("Error! Invalid Argument.");
        }

        this.taskId = taskId;
        this.name = name;
        this.description = description;
        this.dueDate = new Date(dueDate.getTime());
        this.priority = priority;
    }

    public String getTaskId() {
        return taskId;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public Date getDueDate() {
        return new Date(dueDate.getTime());
    }

    public Priority getPriority() {
        return priority;
    }

    public void setName(String name) {
        if (name == null || name.length() > 20) {
            throw new IllegalArgumentException("Error! Invalid Argument.");
        }
        this.name = name;
    }

    public void setDescription(String description) {
        if (description == null || description.length() > 50) {
            throw new IllegalArgumentException("Error! Invalid Argument.");
        }
        this.description = description;
    }

    public void setDueDate(Date dueDate) {
        if (dueDate == null || dueDate.before(new Date())) {
            throw new IllegalArgumentException("Error! Invalid Argument.");
        }
        this.dueDate = new Date(dueDate.getTime());
    }

    public void setPriority(Priority priority) {
        if (priority == null) {
            throw new IllegalArgumentException("Error! Invalid Argument.");
        }
        this.priority = priority;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Task)) {
            return false;
        }
        Task other = (Task) obj;
        return Objects.equals(taskId, other.taskId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(taskId);
    }
}
