import java.util.ArrayList;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AppointmentService {

    private final Map<String, Appointment> appointmentMap = new HashMap<>();
    private final List<Appointment> appointmentList = new ArrayList<>();

    public List<Appointment> getAppointments() {
        return new ArrayList<>(appointmentList);
    }

    public List<Appointment> getAppointmentsSortedByDate() {
        List<Appointment> sorted = new ArrayList<>(appointmentList);
        sorted.sort(Comparator.comparing(Appointment::getDate));
        return sorted;
    }

    public Appointment getAppointmentById(String appointmentId) {
        if (appointmentId == null) {
            throw new IllegalArgumentException("Appointment id cannot be null.");
        }
        return appointmentMap.get(appointmentId);
    }

    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment cannot be null.");
        }
        String appointmentId = appointment.getAppointmentId();
        if (appointmentMap.containsKey(appointmentId)) {
            throw new IllegalArgumentException("Appointment id already exists.");
        }
        appointmentMap.put(appointmentId, appointment);
        appointmentList.add(appointment);
    }

    public void deleteAppointment(String appointmentId) {
        Appointment appointment = getAppointmentById(appointmentId);
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment not found.");
        }
        appointmentMap.remove(appointmentId);
        appointmentList.remove(appointment);
    }

    public void updateAppointmentDate(String appointmentId, Date date) {
        Appointment appointment = getAppointmentById(appointmentId);
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment not found.");
        }
        appointment.setDate(date);
    }

    public void updateAppointmentField(String appointmentId, String field) {
        Appointment appointment = getAppointmentById(appointmentId);
        if (appointment == null) {
            throw new IllegalArgumentException("Appointment not found.");
        }
        appointment.setField(field);
    }

    public List<Appointment> findAppointmentsBetween(Date start, Date end) {
        if (start == null || end == null || start.after(end)) {
            throw new IllegalArgumentException("Invalid date range.");
        }
        List<Appointment> found = new ArrayList<>();
        for (Appointment appointment : appointmentList) {
            Date appointmentDate = appointment.getDate();
            if (!appointmentDate.before(start) && !appointmentDate.after(end)) {
                found.add(appointment);
            }
        }
        return found;
    }
}